<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title><c:choose><c:when test="${not empty contact}">Edit</c:when><c:otherwise>Add</c:otherwise></c:choose> Contact</title>
  <jsp:include page="header.jsp"/>
</head>
<body>
<div class="container card">
  <h2>
    <c:choose>
      <c:when test="${not empty contact}">Edit Contact #${contact.id}</c:when>
      <c:otherwise>Add New Contact</c:otherwise>
    </c:choose>
  </h2>

  <form action="<%= request.getContextPath() %>/contacts" method="post" class="form-grid">
    <c:choose>
      <c:when test="${not empty contact}">
        <input type="hidden" name="action" value="update"/>
        <input type="hidden" name="id" value="${contact.id}"/>
      </c:when>
      <c:otherwise>
        <input type="hidden" name="action" value="create"/>
      </c:otherwise>
    </c:choose>

    <label>Name</label>
    <input type="text" name="name" value="${contact.name}" required />

    <label>Email</label>
    <input type="email" name="email" value="${contact.email}" required />

    <label>Phone</label>
    <input type="text" name="phone" value="${contact.phone}" />

    <div class="form-actions">
      <button type="submit" class="btn primary">
        <c:choose>
          <c:when test="${not empty contact}">Update</c:when>
          <c:otherwise>Create</c:otherwise>
        </c:choose>
      </button>
      <a class="btn outline" href="<%= request.getContextPath() %>/contacts">Cancel</a>
    </div>
  </form>
</div>
</body>
</html>

