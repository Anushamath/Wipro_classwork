<%@ page isErrorPage="true" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Error</title>
  <link rel="stylesheet" href="<%= request.getContextPath() %>/assets/app.css">
</head>
<body>
<div class="container card">
  <h2>Something went wrong</h2>
  <pre><%= exception == null ? "Unknown error" : exception.getMessage() %></pre>
  <a class="btn" href="<%= request.getContextPath() %>/contacts">Back</a>
</div>
</body>
</html>


