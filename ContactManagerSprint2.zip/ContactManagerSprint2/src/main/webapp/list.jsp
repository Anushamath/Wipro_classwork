<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Contacts</title>
  <jsp:include page="header.jsp"/>
</head>
<body>
<div class="container card">
  <div class="card-header">
    <h2>All Contacts</h2>
    <a class="btn" href="<%= request.getContextPath() %>/contacts?action=new">+ Add</a>
  </div>

  <c:choose>
    <c:when test="${empty contacts}">
      <p class="muted">No contacts yet. Click <b>+ Add</b> to create your first contact.</p>
    </c:when>
    <c:otherwise>
      <table class="table">
        <thead>
        <tr>
          <th>#</th><th>Name</th><th>Email</th><th>Phone</th><th class="actions">Actions</th>
        </tr>
        </thead>
        <tbody>
        <c:forEach items="${contacts}" var="c">
          <tr>
            <td>${c.id}</td>
            <td>${c.name}</td>
            <td>${c.email}</td>
            <td>${c.phone}</td>
            <td class="actions">
              <a class="btn outline" href="<%= request.getContextPath() %>/contacts?action=edit&id=${c.id}">Edit</a>
              <form action="<%= request.getContextPath() %>/contacts" method="post" class="inline">
                <input type="hidden" name="action" value="delete"/>
                <input type="hidden" name="id" value="${c.id}"/>
                <button class="btn danger" type="submit" onclick="return confirm('Delete this contact?')">Delete</button>
              </form>
            </td>
          </tr>
        </c:forEach>
        </tbody>
      </table>
    </c:otherwise>
  </c:choose>
</div>
</body>
</html>

