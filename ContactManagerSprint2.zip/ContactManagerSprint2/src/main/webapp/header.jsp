<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<link rel="stylesheet" href="<%= request.getContextPath() %>/assets/app.css" />
<div class="topbar">
  <div class="brand">📒 Contact Manager</div>
  <div class="nav">
    <a href="<%= request.getContextPath() %>/contacts">Home</a>
    <a class="primary" href="<%= request.getContextPath() %>/contacts?action=new">Add Contact</a>
  </div>
</div>

<%-- flash messages from query params --%>
<%
  String msg = request.getParameter("msg");
  String err = request.getParameter("err");
%>
<% if (msg != null) { %>
  <div class="alert success"><%= msg %></div>
<% } %>
<% if (err != null) { %>
  <div class="alert danger"><%= err %></div>
<% } %>
