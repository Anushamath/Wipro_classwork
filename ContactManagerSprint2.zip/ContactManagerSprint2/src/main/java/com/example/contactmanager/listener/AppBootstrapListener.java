package com.example.contactmanager.listener;

import com.example.contactmanager.dao.InMemoryContactDAO;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class AppBootstrapListener implements ServletContextListener {
    public static final String DAO_KEY = "contactDAO";

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        InMemoryContactDAO dao = new InMemoryContactDAO();
        dao.seed();
        sce.getServletContext().setAttribute(DAO_KEY, dao);
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) { /* no-op */ }
}

