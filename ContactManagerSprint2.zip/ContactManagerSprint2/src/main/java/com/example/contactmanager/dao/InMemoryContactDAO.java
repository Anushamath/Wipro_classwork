package com.example.contactmanager.dao;

import com.example.contactmanager.model.Contact;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class InMemoryContactDAO implements ContactDAO {
    private final Map<Integer, Contact> store = new ConcurrentHashMap<>();
    private final AtomicInteger seq = new AtomicInteger(0);

    @Override public List<Contact> findAll() {
        List<Contact> list = new ArrayList<>(store.values());
        list.sort(Comparator.comparing(Contact::getId));
        return list;
    }

    @Override public Optional<Contact> findById(int id) {
        return Optional.ofNullable(store.get(id));
    }

    @Override public Contact add(Contact c) {
        int id = seq.incrementAndGet();
        c.setId(id);
        store.put(id, c);
        return c;
    }

    @Override public boolean update(Contact c) {
        if (!store.containsKey(c.getId())) return false;
        store.put(c.getId(), c);
        return true;
    }

    @Override public boolean delete(int id) {
        return store.remove(id) != null;
    }

    /** seed a few contacts */
    public void seed() {
        if (store.isEmpty()) {
            add(new Contact("Aarav Mehta", "aarav@example.com", "9876543210"));
            add(new Contact("Diya Sharma", "diya@example.com", "9123456780"));
            add(new Contact("Kabir Khan", "kabir@example.com", "9000000001"));
        }
    }
}
