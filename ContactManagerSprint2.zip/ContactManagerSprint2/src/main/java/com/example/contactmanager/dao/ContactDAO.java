package com.example.contactmanager.dao;

import com.example.contactmanager.model.Contact;
import java.util.List;
import java.util.Optional;

public interface ContactDAO {
    List<Contact> findAll();
    Optional<Contact> findById(int id);
    Contact add(Contact c);
    boolean update(Contact c);
    boolean delete(int id);
}


