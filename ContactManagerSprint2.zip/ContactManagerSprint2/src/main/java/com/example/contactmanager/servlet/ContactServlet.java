package com.example.contactmanager.servlet;

import com.example.contactmanager.dao.ContactDAO;
import com.example.contactmanager.listener.AppBootstrapListener;
import com.example.contactmanager.model.Contact;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

@WebServlet(name = "ContactServlet", urlPatterns = {"/contacts"})
public class ContactServlet extends HttpServlet {

    private ContactDAO dao(HttpServletRequest req) {
        return (ContactDAO) getServletContext().getAttribute(AppBootstrapListener.DAO_KEY);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        if (action == null || action.equals("list")) {
            List<Contact> contacts = dao(req).findAll();
            req.setAttribute("contacts", contacts);
            req.getRequestDispatcher("/list.jsp").forward(req, resp);
            return;
        }

        if (action.equals("new")) {
            // open empty form
            req.getRequestDispatcher("/form.jsp").forward(req, resp);
            return;
        }

        if (action.equals("edit")) {
            int id = parseId(req);
            Optional<Contact> c = dao(req).findById(id);
            if (c.isPresent()) {
                req.setAttribute("contact", c.get());
                req.getRequestDispatcher("/form.jsp").forward(req, resp);
            } else {
                resp.sendRedirect(req.getContextPath() + "/contacts?err=Contact+not+found");
            }
        } else {
            resp.sendRedirect(req.getContextPath() + "/contacts");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        if (action == null) action = "create";

        switch (action) {
            case "create": {
                String name = trim(req.getParameter("name"));
                String email = trim(req.getParameter("email"));
                String phone = trim(req.getParameter("phone"));

                if (name.isEmpty() || email.isEmpty()) {
                    resp.sendRedirect(req.getContextPath() + "/contacts?err=Name+and+Email+are+required");
                    return;
                }
                dao(req).add(new Contact(name, email, phone));
                resp.sendRedirect(req.getContextPath() + "/contacts?msg=Contact+added+successfully");
                break;
            }
            case "update": {
                int id = parseId(req);
                String name = trim(req.getParameter("name"));
                String email = trim(req.getParameter("email"));
                String phone = trim(req.getParameter("phone"));

                if (name.isEmpty() || email.isEmpty()) {
                    resp.sendRedirect(req.getContextPath() + "/contacts?err=Name+and+Email+are+required");
                    return;
                }
                boolean ok = dao(req).update(new Contact(id, name, email, phone));
                if (ok) {
                    resp.sendRedirect(req.getContextPath() + "/contacts?msg=Contact+updated");
                } else {
                    resp.sendRedirect(req.getContextPath() + "/contacts?err=Update+failed");
                }
                break;
            }
            case "delete": {
                int id = parseId(req);
                boolean ok = dao(req).delete(id);
                String p = ok ? "msg=Contact+deleted" : "err=Delete+failed";
                resp.sendRedirect(req.getContextPath() + "/contacts?" + p);
                break;
            }
            default:
                resp.sendRedirect(req.getContextPath() + "/contacts");
        }
    }

    private static int parseId(HttpServletRequest req) {
        try { return Integer.parseInt(req.getParameter("id")); }
        catch (Exception e) { return -1; }
    }

    private static String trim(String s) { return s == null ? "" : s.trim(); }
}
