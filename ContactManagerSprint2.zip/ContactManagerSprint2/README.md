# Contact Manager • Sprint 2

JSP + Servlets (Maven WAR) application implementing:
- List previous contacts
- Add new contact (with success message)
- Modify contact
- Delete contact
- Validation + friendly error messages

## Run in Eclipse (Tomcat 9+)

1) **Import**
   - File → Import… → *Existing Maven Projects*
   - Select the folder you unzipped (`ContactManagerSprint2`).
   - Finish (Eclipse will resolve Maven deps).

2) **Configure Server**
   - Window → Show View → *Servers*.
   - Right‑click → *New* → *Server* → *Apache* → *Tomcat v9.0 Server*.
   - Point to your Tomcat install.

3) **Run**
   - Right‑click project → *Run As* → *Run on Server*.
   - Open: http://localhost:8080/ContactManagerSprint2/

> Tip: If you use Tomcat 10+, migrate to the *jakarta.* namespace or run Tomcat 9 for `javax.*` compatibility.

## Project Structure

- `src/main/java`
  - `model/Contact.java`
  - `dao/ContactDAO.java`, `dao/InMemoryContactDAO.java`
  - `servlet/ContactServlet.java`
  - `listener/AppBootstrapListener.java`
- `src/main/webapp`
  - `index.jsp` (redirects to `/contacts`)
  - `WEB-INF/jsp/list.jsp`, `WEB-INF/jsp/form.jsp`, `WEB-INF/jsp/error.jsp`
  - `assets/style.css`
  - `WEB-INF/web.xml`
- `pom.xml`

## Notes

- Data is stored **in-memory** for simplicity. It resets on server restart.
- Uses JSTL (`<c:forEach>`, `<c:if>`, `<c:choose>`, `<jsp:include>`) and EL for a clean JSP.
- UI is responsive and colorful with a dark neon theme.
